Copyright 2018 CA Technologies. All rights reserved.

Server Requirements:
CA PPM Version #: 14.3.x or 14.4.x or 15.1.x or 15.2.x or 15.3.x or 15.4.x or 15.5.x
Jaspersoft Version/Build #: 7.1.0_6.1.0.x or higher version

Client Requirements:
Jaspersoft Studio Professional Version #: 7.1.0
CA JDBC Adapter Version #: 7.1.0

================================================
Jaspersoft Studio Professional CA JDBC Adapter
================================================
The CA JDBC Adapter enables report developers to connect to the CA PPM transactional or data warehouse schemas to run queries from Jaspersoft Studio Professional, without requiring a VPN connection.  The adapter supports up to 1000 rows returned in a query when developing and previewing reports.  The adapter works with Oracle or Microsoft SQL Server databases.


1. Verify the Installation Requirements 

   Before installing and creating the data adapter, you must have the following:
   
   a. CA PPM Jaspersoft 7.1.0_6.1.0.x or higher. You can find the CA PPM Jaspersoft Version/Build information in the CA PPM About link.

   b. Jaspersoft Studio Professional 7.1.0 or higher version downloaded and installed.

   c. The ca_jdbc_adapter_7.1.0.3.zip file included with the Jaspersoft Studio Professional image that you downloaded from the CA Technologies Support site.

   d. The reporting server URL and organization ID information available in System Options-Advanced Reporting (CA PPM/Administration/General Settings/System Options-Advanced Reporting). 

      - Advanced Reporting Server URL
      - Organization ID

   e. A report developer user created in Advanced Reporting (CA PPM/Advanced Reporting/Manage/Users).

      If the report developer user does not exist, ask your Administrator to create a user. 
      The report developer user must be created directly in Advanced Reporting (CA PPM/Advanced Reporting/Manage/Users) and not as a resource in CA PPM.  You must also assign the 
      ROLE_ADMINISTRATOR role to the report developer user in Advanced Reporting.  


2. Install the CA JDBC Adapter

   The installation process is as follows:

   a. Exit Jaspersoft Studio Professional if the application is running.

   b. Create a folder under your local workspace and name it, for example, drivers.

      If you do not know where your workspace is located, you can verify it from Jaspersoft Studio Professional. Navigate to File and select Switch Workspace. 
      The 'Workspace Root Path' indicates the location of your workspace. For example: C:\workspace\Studio. Click Cancel.

   c. Copy the contents of the ca_jdbc_adapter_7.1.0.3.zip file to the folder you created in the previous step. It should include the following jar files:

      - ca_jdbc_adapter_7.1.0.3.jar  -->  CA JDBC Adapter jar file
      - jdbc\ojdbc8-12.2.0.1.0.jar     -->  Oracle 11g & 12c native JDBC driver jar file


   d. Reopen Jaspersoft Studio Professional.


3. Create a new CA JDBC Adapter in Jaspersoft Studio Professional

   Perform the following steps for each schema and environment you reference in developing reports.  If you develop reports against the CA PPM transactional and data warehouse schemas, you must create an adapter for each.  You may only reference one adapter at a time per report.

   a. In Jaspersoft Studio Professional, navigate to the Repository Explorer view and right click Data Adapters. Select Create Data Adapter to open the Data Adapter Wizard.

   b. Select 'Database JDBC Connection' from the list of Data Adapters and click Next. 

   c. On the Database Location tab, provide the following information:

      - Name:         The name of the data adapter. For example: CA PPM TXN Development, CA PPM DWH Development, CA PPM TXN Test, CA PPM DWH Test, etc.

      - JDBC Driver:  com.jaspersoft.jdbc.driver.JasperDriver
                      
                      This option is not available from the drop down list. You must type the JBDC driver exactly as specified above, or copy/paste.
    
      - JDBC Url:     Follow the format:  

                      jdbc:jaspersoft@<ADVANCED_REPORTING_SERVER_URL>;datasource=<BEAN_DATA_SOURCE_REPOSITORY_PATH>;pagesize=<PAGE_SIZE>

                      where:  
			                      
                      <ADVANCED_REPORTING_SERVER_URL> is the complete Advanced Reporting Server URL available in System Options-Advanced Reporting (CA PPM/Administration/General Settings/System Options-Advanced Reporting).
  
                      <BEAN_DATA_SOURCE_REPOSITORY_PATH> is the path in the organization repository where the Bean data source is located. The path is relative to the organization.  

                      CA PPM Bean Data Source example:
                      jdbc:jaspersoft@https://cappm1234.ondemand.ca.com/reportservice;datasource=/ca_ppm/data_sources/CA_PPM_BEAN;pagesize=500

                      CA PPM Data Warehouse Bean Data Source example:
                      jdbc:jaspersoft@https://cappm1234.ondemand.ca.com/reportservice;datasource=/ca_ppm/data_sources/CA_PPM_DWH_BEAN;pagesize=500

                      <PAGE_SIZE> is the number of records that the adapter fetches at a time from the server. The maximum limit is a server setting of 500. You can specify a page size value in the range of 100-500. If you specify a value greater than 500, the data adapter will fetch 500 records at a time only because the server setting takes precedence.  This page size setting does not control the number of rows returned in a query.  There is another setting on the server that determines the maximum rows returned in a query and it is set at 1000 rows.  The page size is a fetch mechanism to transmit records over the network and is transparent to the report developer.  
	
      - Username:     <USERNAME>|<ORGANIZATION_ID>

                      This is the report developer user created in Advanced Reporting and the Organization ID available in System Options-Advanced Reporting.
                      For example: report_developer|cappm1234_dev

      - Password:     <PASSWORD>

                      This is the report developer user password in Advanced Reporting.

    d. Navigate to the Driver Classpath tab and click Add. 

    e. Navigate to the folder where you copied the jar files and add the files to the classpath. 
	
       Two Oracle native JDBC driver jar files are included in the zip file. Use the JDBC driver compatible with the Oracle version of the CA PPM transactional and data warehouse schemas.   
	   
       For Oracle 11g, the Jar Files Path window should display this after adding the files:
       <PATH>\ca_jdbc_adapter_7.1.0.3.jar
       <PATH>\jdbc\ojdbc8-12.2.0.1.0.jar 
	   
       Oracle 11g example:
       C:\workspace\Studio\drivers\ca_jdbc_adapter_7.1.0.3.jar
       C:\workspace\Studio\drivers\jdbc\ojdbc8-12.2.0.1.0.jar 
	   
       For Oracle 12c, the Jar Files Path window should display this after adding the files:
       <PATH>\ca_jdbc_adapter_6.4.2.1.jar	   
       <PATH>\jdbc\ojdbc8-12.2.0.1.0.jar

       Oracle 12c example:
       C:\workspace\Studio\drivers\ca_jdbc_adapter_7.1.0.3.jar	   
       C:\workspace\Studio\drivers\jdbc\ojdbc8-12.2.0.1.0.jar
       
       
    f. Click Test to check that the adapter is set up properly.

    g. Click Finish to save the data adapter.

    h. Select the data adapter - from either the Dataset and Query Dialog, or Preview - when developing reports in Jaspersoft Studio Professional.
	
	
Additional Notes
	
      - The CA JDBC Adapter supports SQL language.  It does not support PLSQL based report development.

      - When working with Oracle database and CLOB, NCLOB, and BLOB columns in the report query, you must modify the Field's Class Type to "java.sql.Clob","java.sql.NClob", and "java.sql.Blob" respectively. 

        The Read Fields button available on the Dataset and Query Dialog uses "oracle.sql.CLOB", "oracle.sql.NCLOB", and "oracle.sql.BLOB" class types as the default for CLOB, NCLOB, or BLOB columns. After creating fields using the Read Fields button, replace these class types by the corresponding "java.sql." class type that is described above.

      - When working with Oracle database and SYSTIMESTAMP columns in the report query, you must modify the Fields' Class Type to "java.sql.Timestamp".

        The Read Fields button available on the Dataset and Query Dialog uses "oracle.sql.TIMESTAMPTZ" class type as the default for SYSTIMESTAMP columns. After creating fields using the Read Fields button, replace this class type by the "java.sql.Timestamp" class type.  